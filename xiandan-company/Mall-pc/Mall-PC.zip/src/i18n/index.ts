export * from 'zent/es/i18n'
export * from './locale'