
module.exports = {
  mode: 'production',
  watch: false,
};
